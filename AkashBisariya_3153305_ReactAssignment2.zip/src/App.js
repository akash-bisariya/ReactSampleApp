import './App.css';
import { BlogForm } from './component/BlogFormCls'

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <BlogForm />
      </header>
    </div>
  );
}

export default App;
